// + + + + + + + + + + + + + + + + + + + + + + + + + + + + + +
//
// FLOAT LABEL
// src : http://jsfiddle.net/RyanWalters/z9ymd852/
//
// + + + + + + + + + + + + + + + + + + + + + + + + + + + + + +
var fn_float_label = function () {

  $('.float-target').on('focus blur', function (e) {
      $(this).parents('.float-target-parent').toggleClass('focused', (e.type === 'focus' || this.value != ''));
  });

  $('.float-target').each(function () {
      if($(this).val() != "") {
          $(this).parents('.float-target-parent').addClass('focused');
      }
  });

}
var fn_carousel = function () {
    // $('.owl-carousel').owlCarousel({
    //     loop:true,
    //     margin:10,
    //     nav:true,
    //     responsive:{
    //         0:{
    //             items:1
    //         },
    //         768:{
    //             items:3
    //         },
    //         1024:{
    //             items:5
    //         }
    //     }
    // })

    $('#carousel-hero-banner').owlCarousel({
        items: 1,
        loop:true,
        nav:true,
        navText : false,
        dots: true,
        margin:10,
        singleItem:true
    })
}
$(document).ready(function() {
    fn_float_label();
    fn_carousel();
});


//# sourceMappingURL=app.js.map
