var fn_carousel = function () {
    // $('.owl-carousel').owlCarousel({
    //     loop:true,
    //     margin:10,
    //     nav:true,
    //     responsive:{
    //         0:{
    //             items:1
    //         },
    //         768:{
    //             items:3
    //         },
    //         1024:{
    //             items:5
    //         }
    //     }
    // })

    $('#carousel-hero-banner').owlCarousel({
        items: 1,
        loop:true,
        nav:true,
        navText : false,
        dots: true,
        margin:10,
        singleItem:true
    })
}