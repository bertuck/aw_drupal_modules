# AW ENTITY BROWSER :

* Requires - Drupal 8.6
* Kenni Bertucat


## Overview:

* This module provide an entity browser (image/document/videos),
Entity browser image, entity browser document and entity browser ckeditor via full html.
This modules saves a lot of time in a typical installation.


## Important to create a field entity browser :


1. Create Media field and select a media type. ex: 'field_image, field_video, field_document' 
2. Go to Manage Form Display in field settings
and select : 

    * Widget settings: Entity browser
    * Entity browser : Entity browser images or Entity browser documents or Entity browser videos, depend on media type
    * Entity display plugin : Rendered Entity
    * View mode : Teaser
