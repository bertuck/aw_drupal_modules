# Architecture Front-End

- jQuery Slim
- Bootstrap 4.3.1
- BEM pour le nommage des class et id
- SASS pour le CSS
- Accessibilité : RGAA (AA) exigé


# Génération du projet

- Installer NodeJS _(version projet : 6.2.0)_
- Installer NPM _(version projet : 5.6.0)_
- Installer Gulp : 
```javascript
npm install --global gulp-cli
```
- Lancer la commande :
```javascript
npm install --save-dev
```
- Le projet s'installe avec les dépendances node_modules
- Lancer la commande :
```javascript
gulp
```
- Le _gulpfile.js_ est interprété
- Le dossier *_static-build* est généré
- Les assets (css, js, img) sont envoyés dans le theme drupal selon le lien référencé dans le _gulpfile.js_


# Si le GULP plante
Faire :

- rm -rf node_modules
- rm -rf package-lock.json
- npm cache clean --force
- npm install

source : https://github.com/gulpjs/gulp/issues/2162#issuecomment-384885950(https://github.com/gulpjs/gulp/issues/2162#issuecomment-384885950)
