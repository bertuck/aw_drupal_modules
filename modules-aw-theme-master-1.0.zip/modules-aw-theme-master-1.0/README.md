# AW Theme Master for Drupal 8


Se theme doit être utilisé comme thème parent, il est relié au profile aw_profile_basic.
Pour mettre à jour le theme aller voir le fichier Readme dans le dossier static-builder.

##Informations 
- jQuery Slim
- Bootstrap 4.3.1
- BEM pour le nommage des class et id
- SASS pour le CSS
- Accessibilité : RGAA (AA) exigé

