AW Profile Basic :
----------------------
Requires - Drupal 8
Kenni Bertucat


Overview:
--------
This profile enhances the Drupal 8 experience.
It does not handle multilingual or multiwebsite.
It is a basic installation but with a lot of improvements.
This saves time on a typical installation.

Installation:
------------
Install the Drupal Website with drush and specify this profil.
drush si aw_profile_basic --db-url=mysql://user:pwd@localhost/database --site-name=D8 --account-name=admin --account-pass=admin


Commandes utiles pour mettre a jour la config du theme si besoin
_________________________________________________________________

drush "cexy --destination=/var/www/html/web/profiles/aw_profile_basic/config/optional --ignore-list=/var/www/html/web/profiles/aw_profile_basic/config/config-ignore-local.yml -y"
drush "cimy --source=/var/www/html/web/profiles/aw_profile_basic/config/optional --delete-list=/var/www/html/web/profiles/aw_profile_basic/config/config-delete-local.yml -y"