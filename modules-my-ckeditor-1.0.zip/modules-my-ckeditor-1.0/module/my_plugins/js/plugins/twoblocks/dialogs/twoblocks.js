CKEDITOR.dialog.add( 'twoblocksDialog', function( editor ) {
    return {
        title: 'Propriétés des blocs',
        minWidth: 400,
        minHeight: 70,

        contents: [
            {
                id: 'tab-basic',
                label: 'Block Left Settings',
                elements: [
                    {
                        type: 'text',
                        id: 'text',
                        label: 'Texte',
                        validate: CKEDITOR.dialog.validate.notEmpty( "Title field cannot be empty." )
                    },
                    {
                        type: 'text',
                        id: 'link_label',
                        label: 'Lien Label',
                        validate: CKEDITOR.dialog.validate.notEmpty( "Label field cannot be empty." )
                    },
                    {
                        type: 'text',
                        id: 'link_uri',
                        label: 'Lien url',
                        validate: CKEDITOR.dialog.validate.notEmpty( "Url field cannot be empty." )
                    }
                ]
            },
            {
                id: 'tab-basic2',
                label: 'Block Right Settings',
                elements: [
                    {
                        type: 'text',
                        id: 'text',
                        label: 'Texte',
                        validate: CKEDITOR.dialog.validate.notEmpty( "Title field cannot be empty." )
                    },
                    {
                        type: 'text',
                        id: 'link_label',
                        label: 'Lien Label',
                        validate: CKEDITOR.dialog.validate.notEmpty( "Label field cannot be empty." )
                    },
                    {
                        type: 'text',
                        id: 'link_uri',
                        label: 'Lien url',
                        validate: CKEDITOR.dialog.validate.notEmpty( "Url field cannot be empty." )
                    }
                ]
            }
        ],
        onOk: function() {
            var dialog = this;

            var blocks = editor.document.createElement( 'div' );
            blocks.setAttribute('class', 'ckeditor-blocks');

            var block_left = editor.document.createElement( 'div' );
            block_left.setAttribute('class', "block-partenaire--wrapper");
            block_left.setAttribute('class', "left");
            var text_left = dialog.getValueOf( 'tab-basic', 'text');
            var link_label_left = dialog.getValueOf( 'tab-basic', 'link_label');
            var link_uri_left = dialog.getValueOf( 'tab-basic', 'link_uri');

            var block_text_left = editor.document.createElement( 'div' );
            block_text_left.setAttribute('class', "block-partenaire--txt");
            var block_text_inner_left = editor.document.createElement( 'p' );
            block_text_inner_left.setText(text_left);
            block_text_left.append(block_text_inner_left);
            block_left.append(block_text_left);

            var block_link_left = editor.document.createElement( 'a' );
            block_link_left.setAttribute('class', "btn");
            block_link_left.setAttribute('href', link_uri_left);
            block_link_left.setText(link_label_left);
            block_left.append(block_link_left);



            var block_right = editor.document.createElement( 'div' );
            block_right.setAttribute('class', "block-partenaire--wrapper");
            block_right.setAttribute('class', "right");
            var text_right = dialog.getValueOf( 'tab-basic2', 'text');
            var link_label_right = dialog.getValueOf( 'tab-basic2', 'link_label');
            var link_uri_right = dialog.getValueOf( 'tab-basic2', 'link_uri');

            var block_text_right = editor.document.createElement( 'div' );
            block_text_right.setAttribute('class', "block-partenaire--txt");
            var block_text_inner_right = editor.document.createElement( 'p' );
            block_text_inner_right.setText(text_right);
            block_text_right.append(block_text_inner_right);
            block_right.append(block_text_right);

            var block_link_right = editor.document.createElement( 'a' );
            block_link_right.setAttribute('class', "read-more-arrow");
            block_link_right.setAttribute('href', link_uri_right);
            block_link_right.setText(link_label_right);
            block_right.append(block_link_right);

            blocks.append(block_left);
            blocks.append(block_right);

            editor.insertElement( blocks );
        }
    };
});