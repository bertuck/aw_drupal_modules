$(document).ready(function() {
    fn_float_label();
    fn_carousel();
});

