MY CKEDITOR :
----------------------
Requires - Drupal 8
Kenni Bertucat


Overview:
--------
This module provide a custom ckeditor with plugins.
his saves time on a typical installation.