CKEDITOR.dialog.add( 'customlinkDialog', function( editor ) {
    return {
        title: 'Propriétés du lien',
        minWidth: 400,
        minHeight: 70,

        contents: [
            {
                id: 'tab-basic',
                label: 'Icon Settings',
                elements: [
                    {
                        type: 'text',
                        id: 'label',
                        label: 'Label',
                        validate: CKEDITOR.dialog.validate.notEmpty( "label field cannot be empty." )
                    },
                    {
                        type: 'text',
                        id: 'uri',
                        label: 'Lien',
                        validate: CKEDITOR.dialog.validate.notEmpty( "uri field cannot be empty." )
                    },
                    {
                        type: 'text',
                        id: 'title',
                        label: 'Attribute title',
                        validate: CKEDITOR.dialog.validate.notEmpty( "title field cannot be empty." )
                    },
                    {
                        type: 'select',
                        id: 'target',
                        label: 'Target',
                        items: [ [ 'none' ], [ '_blank' ], [ '_self' ],[ '_parent' ],[ '_top' ] ],
                        'default': 'none'
                    }
                ]
            }
        ],
        onOk: function() {
            var dialog = this;

            var link = editor.document.createElement( 'a' );
            var link_label = dialog.getValueOf( 'tab-basic', 'label');
            var link_uri = dialog.getValueOf( 'tab-basic', 'uri');
            var link_title_attr = dialog.getValueOf( 'tab-basic', 'title');
            var link_target = dialog.getValueOf( 'tab-basic', 'target');

            link.setAttribute('href', link_uri);
            link.setAttribute('title', link_title_attr);
            if (link_target != 'none') {
                link.setAttribute('target', link_target);
            }
            link.setText(link_label);
            editor.insertElement( link );
        }
    };
});