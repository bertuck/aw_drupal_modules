/*
 * gulpfile.js -- Builds the assets for the style guide.
 */

'use strict';

/*
|--------------------------------------------------------------------------
| DEPENDENCIES
|--------------------------------------------------------------------------
*/
var gulp = require('gulp');

// Twig
var twig = require('gulp-twig');

// Style
var sass = require('gulp-sass');
var cleanCSS = require('gulp-clean-css');
var autoprefixer = require('gulp-autoprefixer');
var sourcemaps = require('gulp-sourcemaps');

// Script
var uglify = require('gulp-uglify');
var resolveDependencies = require('gulp-resolve-dependencies');
var concat = require('gulp-concat');

// Images
//var imagemin = require('gulp-imagemin');

// Snif erreur
var plumber = require('gulp-plumber');

// Merge : Permet de faire plusieurs src en une task
var merge = require('merge-stream');
 
/*
|--------------------------------------------------------------------------
| CONFIGURATION
|--------------------------------------------------------------------------
*/
var ROOT = './';
var target = {
    static_build: '../static/'
}

/*
|--------------------------------------------------------------------------
| TASK GROUPS
|--------------------------------------------------------------------------
*/
gulp.task('default', ['dev']);
gulp.task('dev', ['build', 'watch']);
gulp.task('build', ['twig', 'style', 'script-app', 'script-bootstrap', 'script-plugin', 'asset', 'print']);
gulp.task('watch', ['build']);

/*
|--------------------------------------------------------------------------
| TWIG - Template
| IMPORTANT : Le twig doit être appelé en 1er
| IMPORTANT : Le *.html sert à prendre que les .html à la racine
|--------------------------------------------------------------------------
*/
gulp.task('twig', function () {
    return gulp.src([ROOT + 'twig/page/*.twig'])
        .pipe(twig())
        .pipe(gulp.dest(target.static_build));
});

/*
|--------------------------------------------------------------------------
| STYLEHEET GENERATION AND OPTIMIZATION
|--------------------------------------------------------------------------
*/
gulp.task('style', function () {
    return gulp.src(ROOT + 'style/main.scss')
        .pipe(sourcemaps.init())
        .pipe(plumber())
        .pipe(sass())
        .pipe(autoprefixer({
            browsers: ['last 20 versions']
        }))
        .pipe(sourcemaps.init())
        .pipe(concat('style.css'))
        // .pipe(cleanCSS({ debug: true }, function(details) {
        //   console.log(details.name + ' (before) >>> ' + details.stats.originalSize);
        //   console.log(details.name + ' (after)  >>> ' + details.stats.minifiedSize);
        // }))
        .pipe(sourcemaps.write('.'))
        // .pipe(gulp.dest(target.static_dev + 'style'))
        .pipe(gulp.dest(target.static_build + 'style'))
});

//
// * jquery-open + jquery-close : Fix le bug jQuery dans Drupal
// * jquery-open.js ouvre jQuery
// * jquery-close.js ouvre jQuery
//
// * Le fichier app.js init le fichier généré core.js
//
gulp.task('script-app', function () {
    return gulp.src([
        ROOT + 'script/app/_float-label.js',
        ROOT + 'script/app/_carousel.js',
        // init des scripts du dessus
        ROOT + 'script/app/app.js',
    ])
    .pipe(sourcemaps.init())
    .pipe(resolveDependencies({
        pattern: /\* @requires [\s-]*(.*?\.js)/g
    }))
    .pipe(concat('app.js'))
    //.pipe(uglify())
    .pipe(sourcemaps.write('.'))
    // .pipe(gulp.dest(target.static_dev + 'script'))
    .pipe(gulp.dest(target.static_build + 'script'));
});

//
// On build les JS bootstrap => bootstrap-custom.js
//
gulp.task('script-bootstrap', function () {
    return gulp.src([
        // OPEN
        ROOT + 'script/plugin/jquery/jquery-open.js',
        // Appeler tous les autres scripts ici
        ROOT + 'script/plugin/bootstrap/util.js',
        ROOT + 'script/plugin/bootstrap/alert.js',
        ROOT + 'script/plugin/bootstrap/button.js',
        ROOT + 'script/plugin/bootstrap/carousel.js',
        ROOT + 'script/plugin/bootstrap/collapse.js',
        ROOT + 'script/plugin/bootstrap/dropdown.js',
        ROOT + 'script/plugin/bootstrap/modal.js',
        ROOT + 'script/plugin/bootstrap/tooltip.js', // Tooltip doit être appelé avant popover : https://stackoverflow.com/questions/18599382/twitter-bootstrap-popover-not-working
        ROOT + 'script/plugin/bootstrap/popover.js',
        ROOT + 'script/plugin/bootstrap/scrollspy.js',
        ROOT + 'script/plugin/bootstrap/tab.js',
        ROOT + 'script/plugin/bootstrap/toast.js',
        // CLOSE
        ROOT + 'script/plugin/jquery/jquery-close.js',
    ])
    .pipe(sourcemaps.init())
    .pipe(resolveDependencies({
        pattern: /\* @requires [\s-]*(.*?\.js)/g
    }))
    .pipe(concat('bootstrap-custom.js'))
    //.pipe(uglify())
    .pipe(sourcemaps.write('.'))
    // .pipe(gulp.dest(target.static_dev + 'script'))
    .pipe(gulp.dest(target.static_build + 'script'));
});

//
// On build les JS qui sont dans plugin dans un fichier vendor.js
//
gulp.task('script-plugin', function () {
    return gulp.src([
        // OPEN
        ROOT + 'script/plugin/jquery/jquery-open.js',
        // Appeler tous les autres scripts ici
        ROOT + 'script/plugin/owl-carousel/owl-carousel.js',
        // CLOSE
        ROOT + 'script/plugin/jquery/jquery-close.js',
    ])
    .pipe(sourcemaps.init())
    .pipe(resolveDependencies({
        pattern: /\* @requires [\s-]*(.*?\.js)/g
    }))
    .pipe(concat('vendor.js'))
    //.pipe(uglify())
    .pipe(sourcemaps.write('.'))
    // .pipe(gulp.dest(target.static_dev + 'script'))
    .pipe(gulp.dest(target.static_build + 'script'));
});

/*
|--------------------------------------------------------------------------
| COPY AND PASTE ASSETS
|--------------------------------------------------------------------------
*/
gulp.task('asset', function () {
    var modernizr = gulp.src(ROOT + 'script/plugin/modernizr/modernizr.js')
        // .pipe(gulp.dest(target.static_dev + 'script'))
        .pipe(gulp.dest(target.static_build + 'script'));

    var detectizr = gulp.src(ROOT + 'script/plugin/detectizr/detectizr.js')
        // .pipe(gulp.dest(target.static_dev + 'script'))
        .pipe(gulp.dest(target.static_build + 'script'));

    var jquery = gulp.src(ROOT + 'script/plugin/jquery/jquery-3-3-1-slim-min.js')
        // .pipe(gulp.dest(target.static_dev + 'script'))
        .pipe(gulp.dest(target.static_build + 'script'));

    var popper = gulp.src(ROOT + 'script/plugin/popper/popper-min.js')
        // .pipe(gulp.dest(target.static_dev + 'script'))
        .pipe(gulp.dest(target.static_build + 'script'));

    var font = gulp.src(ROOT + 'font/**/*.*')
        // .pipe(gulp.dest(target.static_dev + 'font'))
        .pipe(gulp.dest(target.static_build + 'font'));

    var img = gulp.src(ROOT + 'img/**/*')
        // .pipe(gulp.dest(target.static_dev + 'img'))
        .pipe(gulp.dest(target.static_build + 'img'));

    return merge(img, font, jquery, detectizr, modernizr, popper);
});


gulp.task('clean', function () {
    return del([ '../static-build/**/*' ], {force:true})
});

/*
|--------------------------------------------------------------------------
| WATCH TASKS
|--------------------------------------------------------------------------
*/
gulp.task('watch', function () {
    gulp.watch(ROOT + 'style/**/*.scss', ['style']);
    gulp.watch(ROOT + 'style/print.scss', ['print']);

    gulp.watch(ROOT + 'script/plugin/**/*.js', ['script-bootstrap']);
    gulp.watch(ROOT + 'script/plugin/**/*.js', ['script-plugin']);
    gulp.watch(ROOT + 'script/app/**/*.js', ['script-app']);

    gulp.watch(ROOT + 'twig/**/*.twig', ['twig']);
});

/*
|--------------------------------------------------------------------------
| PRINT CSS
|--------------------------------------------------------------------------
*/
gulp.task('print', function () {
    return gulp.src(ROOT + 'style/print.scss')
        .pipe(sass())
        .pipe(concat('print.css'))
        // .pipe(gulp.dest(target.static_dev + 'style'))
        .pipe(gulp.dest(target.static_build + 'style'));
});