CMI TOOLS WORKFLOW :
----------------------

Fichiers de config :
----------------------
config-ignore-local.yml -> a utiliser pour l'export de config en local
config-ignore-prod.yml -> a utiliser pour l'export de config sur la recette ou prod


Export config local
--------------------
drush "cexy --destination=/var/www/html/custom/config/local --ignore-list=/var/www/html/web/profiles/aw_profile_basic/config/config-ignore-local.yml -y"

Export config recette ou prod :
-------------------------------
drush "cexy --destination=/var/www/html/custom/config/prod --ignore-list=/var/www/html/web/profiles/aw_profile_basic/config/config-ignore-prod.yml -y"

Import config local :
----------------------
drush "cimy --source=/var/www/html/custom/config/local -y"

Import config recette ou prod :
--------------------------------
drush "cimy --source=/var/www/html/custom/config/prod -y"


Informations importantes :
------------------------

Pour activer ou desactiver un module sur la recette ou prod
il faut utiliser la commande drush 'en' ou 'pm-uninstall' avant l'import de config

Le fichier core.extensions n'est plus géré pour faciliter l'import et l'export de configs